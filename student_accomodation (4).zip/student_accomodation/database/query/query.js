const query = {
    SELECT_ROOMS: "SELECT * FROM rooms",
    SELECT_ROOM: "SELECT * FROM rooms WHERE id = ?",
    CREATE_ROOM: "INSERT INTO rooms(name, capacity, description, isFull) VALUES (?, ?, ?, ?)"
}

module.exports = query;