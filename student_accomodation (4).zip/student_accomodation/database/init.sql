CREATE DATABASE IF NOT EXISTS students_accomodation;

use students_accomodation;

CREATE TABLE rooms(
    id BIGINT UNSIGNED NOT NULL PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(256) NOT NULL,
    capacity INT NOT NULL,
    description VARCHAR(256) NOT NULL,
    isFull BOOLEAN NOT NULL DEFAULT FALSE
);

-- prefill database with rroms
INSERT INTO rooms (name, capacity, description, isFull) VALUES ('Room 1', 2, 'Small room', true);
INSERT INTO rooms (name, capacity, description, isFull) VALUES ('Room 2', 2, 'Small room', false);
INSERT INTO rooms (name, capacity, description, isFull) VALUES ('Room 3', 4, 'Medium room', true);
INSERT INTO rooms (name, capacity, description, isFull) VALUES ('Room 4', 8, 'Large room', false);
INSERT INTO rooms (name, capacity, description, isFull) VALUES ('Room 5', 21, 'Hall', false);
INSERT INTO rooms (name, capacity, description, isFull) VALUES ('Room 6', 4, 'Medium room', false);
INSERT INTO rooms (name, capacity, description, isFull) VALUES ('Room 7', 8, 'Large room', false);
INSERT INTO rooms (name, capacity, description, isFull) VALUES ('Room 8', 1, 'Private room', true);


